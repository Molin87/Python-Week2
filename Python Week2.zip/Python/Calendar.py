#Showing a calendar in Python with ****Moe****

#import calendat built-in python libraries
import calendar
import datetime

#set the calendar to begin on a sunday
calendar.setfirstweekday(calendar.SUNDAY)

#shows the current year and month
print("----Python Calendar----\n")
print(calendar.month(2020,4),"\n")

#checks the current date in other system
current = datetime.datetime.now()

#this will indicate the current year, month, and give day of the week
day_index = calendar.weekday(2020,4,7)
month_index = calendar.month(2020,4)

#display full calendar

# %A is the full day
# %B is the full month name month
# %d is the day of the month
# &Y is the full year
print("Today is", current.strftime('%A %B %d %Y'))

